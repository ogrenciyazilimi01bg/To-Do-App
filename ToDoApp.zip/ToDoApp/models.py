from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Gorev(db.Model):
    __tablename__ = "gorevler"

    id = db.Column(db.Integer, primary_key=True)
    baslik = db.Column(db.String(100), nullable=False)
    aciklama = db.Column(db.String(300))
    durum = db.Column(db.String(20), default="Beklemede")
    deadline = db.Column(db.Date)

    def __init__(self, baslik, aciklama, deadline=None, durum="Beklemede"):
        self.baslik = baslik
        self.aciklama = aciklama
        self.durum = durum
        self.deadline = deadline

    def tamamla(self):
        self.durum = "Tamamlandı"

    def beklemeye_al(self):
        self.durum = "Beklemede"

    def __repr__(self):
        return f"<Gorev {self.baslik}>"
