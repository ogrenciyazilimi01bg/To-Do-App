from flask import Flask, render_template, request, redirect, url_for
from models import db, Gorev
from datetime import datetime, timedelta

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///gorevler.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

# Uygulama bağlamında veritabanını oluştur
with app.app_context():
    db.create_all()

# Context processor: template içinde kullanılacak
@app.context_processor
def utility_processor():
    return dict(now=datetime.now, timedelta=timedelta)

# Ana sayfa
@app.route("/")
def index():
    gorevler = Gorev.query.order_by(Gorev.durum.asc(), Gorev.deadline.asc()).all()
    filtre = request.args.get("durum")  # GET parametresi
    if filtre in ["Beklemede", "Tamamlandı"]:
        gorevler = Gorev.query.filter_by(durum=filtre).order_by(Gorev.deadline.asc()).all()
    else:
        gorevler = Gorev.query.order_by(Gorev.durum.asc(), Gorev.deadline.asc()).all()
    return render_template("index.html", gorevler=gorevler, filtre=filtre)
# Görev ekleme
@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "POST":
        baslik = request.form["baslik"]
        aciklama = request.form["aciklama"]
        deadline_raw = request.form["deadline"]
        deadline = datetime.strptime(deadline_raw, "%Y-%m-%d").date()

        yeni = Gorev(baslik, aciklama, deadline)
        db.session.add(yeni)
        db.session.commit()
        return redirect(url_for("index"))

    return render_template("add.html")

# Durum değiştir
@app.route("/toggle/<int:id>")
def toggle(id):
    gorev = Gorev.query.get(id)
    if gorev.durum == "Beklemede":
        gorev.tamamla()
    else:
        gorev.beklemeye_al()
    db.session.commit()
    return redirect(url_for("index"))

# Görev sil
@app.route("/delete/<int:id>")
def delete(id):
    gorev = Gorev.query.get(id)
    db.session.delete(gorev)
    db.session.commit()
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
